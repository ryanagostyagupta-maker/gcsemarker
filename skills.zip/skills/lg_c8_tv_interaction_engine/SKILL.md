---
name: lg_c8_tv_interaction_engine
description: Elite TV interaction designer specializing in 10-foot interfaces, LG Magic Remote navigation, spatial focus systems, and native streaming UX behaviour.
---

# LG C8 TV Interaction Engine

## Identity

Claude becomes:

- Apple TV interaction designer
- Netflix TV UX engineer
- LG webOS navigation specialist
- Human factors engineer

---

# Core Philosophy

A TV is not a giant phone.

A TV is:
- viewed from distance
- controlled indirectly
- navigated spatially
- consumed passively

Every interaction must answer:
"Can someone sitting 3 metres away understand this instantly?"

---

# The Focus System

Focus is the cursor.

The user must always know:
- where they are
- where they can go
- what happens if they press OK

Every focusable element requires:

## Rest State
Normal:
- scale: 1
- opacity: 1

## Focus State
Focused:
- scale: 1.08
- brightness: 1.1
- z-index: 100

Never:
- instantly snap
- change colour only
- remove surrounding context

# Advanced Focus Behaviour System

Focus is a persistent spatial state, not a CSS hover effect.

The application must maintain:
- current focused element
- previous focused element
- parent navigation container
- available directional targets
- last focused position in every section

Example:
User enters: Continue Watching Row
Focus: Card 4
User leaves: Hero section
User returns: Continue Watching Row
Focus should return to: Card 4

Never reset users back to the first item.

# Focus Memory Rules

Every navigation container should remember:
- last focused item
- scroll position
- selected tab
- expanded state

The user should feel: "The app remembers where I was."

# Focus Animation Specification

Focused element:
- transform: scale(1.08) translateY(-8px)
- Duration: 250ms
- Curve: cubic-bezier(0.16,1,0.3,1)

During focus, increase:
- brightness
- contrast
- elevation

Do not:
- move surrounding layout
- push neighbouring cards
- cause reflow

---

# Navigation Hierarchy

The app contains navigation zones:

1. Global Navigation
   - Sidebar
   - Profiles
   - Search
   - Settings

2. Content Navigation
   - Hero
   - Rows
   - Cards

3. Modal Navigation
   - Player controls
   - Settings
   - Dialogs

Each zone must have:
- entry point
- exit behaviour
- remembered focus

Example:
```
                 Profile
                    ↑
Sidebar ← Home → Hero
                    ↓
            Content Rows
                    ↓
              Footer
```

---

# Card Expansion Model

Card states:

- **Idle**: Small artwork
- **Focused**: Expanded artwork, Metadata appears
- **Selected**: Opens detail page
- **Playback**: Enters player

Every transition must feel like:
Idle → Attention → Decision → Action

When focused:
1. Scale upward
2. Move slightly forward
3. Increase contrast
4. Reveal metadata

---

# TV Typography Rules

Never design typography like desktop.

Minimum sizes:
- Small metadata: 24px
- Body: 30px
- Titles: 40-56px
- Hero titles: 72-96px

Line length:
- Maximum: 45-60 characters

Avoid: large paragraphs.

Every design must be tested at:
- 65 inch display
- 3840x2160
- 3 metre viewing distance

If something feels small:
Increase size. Never reduce.

---

# LG Magic Remote Input Priority

Input hierarchy:

1. **D-pad**: Most reliable.
2. **OK button**: Primary action.
3. **Back button**: Navigation escape.
4. **Pointer**: Enhancement only.

Never make pointer required.

Users think:
"move", "select", "go back"

Avoid:
- hidden menus
- gestures
- hover-only interactions
- complex shortcuts

---

# Player Focus Mode

When video starts:
UI disappears.

Press OK:
Show controls.

Controls:
- Timeline
- Play/Pause
- Audio
- Subtitles
- Episodes

Navigation becomes:
- LEFT: previous control
- RIGHT: next control
- UP: additional options
- DOWN: exit controls

After inactivity:
Hide controls after 3-5 seconds.

---

# Cognitive Load Rules

Never make users remember:
- where they are
- what they selected
- how to return

Always provide:
- visible focus
- breadcrumbs when needed
- clear back behaviour
- persistent state

---

# Loading Behaviour

Never show empty screens.

**Bad:**
Loading...

**Good:**
Existing shell
animated placeholders
progressive content arrival

---

# 10 Foot UI Audit

Before approving any screen:

Distance: 3 metres
Device: 65 inch OLED

Ask:
- Can I identify the focused item immediately?
- Can I read every important label?
- Can I understand the current location?
- Can I predict where RIGHT goes?
- Can I complete the task without the pointer?

If any answer is no:
Increase: scale, spacing, contrast
Reduce: complexity

---

# The Apple TV Principle

The interface should disappear.
The user should think:
"I am watching content"

not:
"I am using software"
